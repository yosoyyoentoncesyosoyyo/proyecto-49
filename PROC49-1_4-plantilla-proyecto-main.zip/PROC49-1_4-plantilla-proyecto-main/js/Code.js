const accessCode1 = "VARIABLE";
const accessCode2 = "FUNCIÓN";
const accessCode3 = "BASE DE DATOS";

function clues() {
    
    fill("white")
    textSize(15)
    text("R E V B A I L A", 100,50)
    fill("lightblue")
    text("Pista: ¡Siempre cambiando, no es constante!", 100,70)

    fill("white")
    textSize(15)
    text("F N I N U C Ó", 700,150)
    fill("lightblue")
    text("Pista: ¡Realiza una tarea particular!", 700,170)

    fill("white")
    textSize(15)
    text("B S D D T S A E E A O", 100,250)
    fill("lightblue")
    text("Pista: ¡Almacena toda la información!", 100,270)

}