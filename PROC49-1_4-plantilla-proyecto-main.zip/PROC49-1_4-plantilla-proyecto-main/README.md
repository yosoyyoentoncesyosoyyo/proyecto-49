# PROC49-1_4-plantilla-proyecto
Plantilla del alumno.  
Búsqueda del tesoro. Etapa 1.  
Modificación por parte del alumno de 2 comentarios.  
  
- Proyect Booster
  
### Texto en inglés: Treasure-hunt-template